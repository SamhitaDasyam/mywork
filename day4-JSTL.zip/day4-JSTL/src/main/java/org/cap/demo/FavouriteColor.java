package org.cap.demo;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class FavouriteColor extends SimpleTagSupport{

	
	private String color;
	
	
	
	public void setColor(String color) {
		this.color = color;
	}



	@Override
	public void doTag() throws JspException, IOException {
		
		 JspWriter out= getJspContext().getOut();
		
		 if(color==null) {
			 out.println("<h1>Hello! Welcome All! </h1>");
		 }else {
			 out.println("<h1 style='color:"+this.color +";'>Hello! Welcome All! </h1>");
		 }
		 
		
	}

	
	
	
}
